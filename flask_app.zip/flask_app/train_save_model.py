# train_save_model.py
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import StackingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import joblib

# Membaca dataset Raisin
data = pd.read_csv('raisin.csv')

# Memisahkan fitur dan label
X = data[['Area', 'MajorAxisLength', 'MinorAxisLength', 'Eccentricity', 
          'ConvexArea', 'Extent', 'Perimeter']].values
y = data['Class'].values

# Mengencode label kelas
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Membagi dataset menjadi set pelatihan dan pengujian
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=0)

# Membuat daftar estimator untuk StackingClassifier
estimators = [(f'KNN {i}', make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=i))) for i in range(3, 31, 1)]

# Inisialisasi StackingClassifier
clf = StackingClassifier(
    estimators=estimators, final_estimator=GaussianNB()
)

# Melatih StackingClassifier
clf.fit(X_train, y_train)

# Menghitung akurasi pada data uji
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

# Menyimpan model, encoder, scaler, dan akurasi
joblib.dump(clf, 'model/model.pkl')
joblib.dump(label_encoder, 'model/label_encoder.pkl')
joblib.dump(StandardScaler().fit(X_train), 'model/scaler.pkl')
joblib.dump(accuracy, 'model/accuracy.pkl')
