from flask import Flask, request, jsonify, render_template, redirect, url_for
import joblib
import numpy as np

app = Flask(__name__)
application = app

# Memuat model, scaler, dan akurasi
model = joblib.load('model/model.pkl')
label_encoder = joblib.load('model/label_encoder.pkl')
scaler = joblib.load('model/scaler.pkl')
accuracy = joblib.load('model/accuracy.pkl')

@app.route('/')
def home():
    return render_template('index.html', accuracy=accuracy)

@app.route('/predict', methods=['POST'])
def predict():
    # Mendapatkan data dari form
    data = request.form
    x_baru = [data['Area'], data['MajorAxisLength'], data['MinorAxisLength'],
              data['Eccentricity'], data['ConvexArea'], data['Extent'], data['Perimeter']]
    x_baru = np.array(x_baru).reshape(1, -1)
    
    # Skalakan data baru
    x_baru_scaled = scaler.transform(x_baru)
    
    # Prediksi kelas
    prediction = model.predict(x_baru_scaled)
    predicted_class = label_encoder.inverse_transform(prediction)
    
    # Redirect ke halaman hasil dengan parameter prediksi dan akurasi
    return redirect(url_for('result', prediction=predicted_class[0], accuracy=accuracy))

@app.route('/result')
def result():
    prediction = request.args.get('prediction')
    accuracy = request.args.get('accuracy')
    return render_template('result.html', prediction=prediction, accuracy=accuracy)

if __name__ == "__main__":
    app.run(debug=True)
